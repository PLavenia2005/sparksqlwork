$ErrorActionPreference = 'Stop'
Write-Host "== Setup: venv, PySpark, OpenJDK, Hadoop =="

Write-Host "Creating venv (if missing)..."
python -m venv venv

$pipPath = Join-Path 'venv\Scripts' 'pip.exe'
Write-Host "Upgrading pip and installing pyspark..."
& $pipPath install --upgrade pip
& $pipPath install pyspark

# Download OpenJDK (Adoptium Temurin 17)
# Use Adoptium API endpoint that returns a binary redirect for Temurin builds
$jdkApi = "https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse?project=jdk"
$jdkZip = "openjdk.zip"
Write-Host "Downloading OpenJDK from Adoptium..."
Invoke-WebRequest -Uri $jdkApi -OutFile $jdkZip -UseBasicParsing -MaximumRedirection 5

$jdkExtractDir = Join-Path $PWD 'jdk'
if (Test-Path $jdkExtractDir) { Remove-Item -Recurse -Force $jdkExtractDir }
New-Item -ItemType Directory -Path $jdkExtractDir | Out-Null
Write-Host "Extracting OpenJDK..."
Expand-Archive -Path $jdkZip -DestinationPath $jdkExtractDir -Force
$jdkInner = Get-ChildItem -Directory $jdkExtractDir | Select-Object -First 1
$jdkFull = $jdkInner.FullName
Write-Host "OpenJDK extracted to: $jdkFull"

# Download Hadoop 3.3.4
$hadoopUrl = "https://downloads.apache.org/hadoop/common/hadoop-3.3.4/hadoop-3.3.4.tar.gz"
$hadoopTar = "hadoop.tar.gz"
Write-Host "Downloading Hadoop 3.3.4..."
Invoke-WebRequest -Uri $hadoopUrl -OutFile $hadoopTar -UseBasicParsing
Write-Host "Extracting Hadoop..."
tar -xzf $hadoopTar -C $PWD
$hadoopDir = Join-Path $PWD 'hadoop-3.3.4'
Write-Host "Hadoop extracted to: $hadoopDir"

# Update venv activation scripts
$activatePS = Join-Path 'venv\Scripts' 'Activate.ps1'
$psAdd = @"
# Added by setup_jdk_hadoop.ps1
`$env:JAVA_HOME='$jdkFull'
`$env:HADOOP_HOME='$hadoopDir'
`$env:PATH='$jdkFull\bin;$hadoopDir\bin;'+$env:PATH
"@

if (Test-Path $activatePS) { Add-Content -Path $activatePS -Value $psAdd }

$activateBat = Join-Path 'venv\Scripts' 'activate.bat'
$batAdd = "\r\n:: Added by setup_jdk_hadoop.ps1\r\nset JAVA_HOME=$jdkFull\r\nset HADOOP_HOME=$hadoopDir\r\nset PATH=%JAVA_HOME%\\bin;%HADOOP_HOME%\\bin;%PATH%\r\n"
if (Test-Path $activateBat) { Add-Content -Path $activateBat -Value $batAdd }

# Verify installations
Write-Host "\n== Verification =="
Write-Host "PySpark version:"
& (Join-Path $PWD 'venv\Scripts\python.exe') -c "import pyspark, sys; print(pyspark.__version__)"

Write-Host "Java version:"
& (Join-Path $jdkFull 'bin\java.exe') -version

Write-Host "Hadoop version (if available):"
$hadoopCmd = Join-Path $hadoopDir 'bin\hadoop.cmd'
if (Test-Path $hadoopCmd) { & $hadoopCmd version } else { Write-Host "hadoop.cmd not found; check $hadoopDir\bin" }

Write-Host "\nSetup complete. Activate the venv with: .\\venv\\Scripts\\Activate.ps1 (PowerShell) or .\\venv\\Scripts\\activate.bat (cmd)"